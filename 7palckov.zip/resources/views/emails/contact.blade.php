<h3>Dobili ste novo sporočilo preko Contact Forme</h3>

<div>
    {{$bodyMessage}}

</div>

<p>Sent via {{$email}}</p>