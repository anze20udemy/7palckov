@extends('layouts.app')

@section('content')
<div class="container">

    <div class="row">
        <div class="col-lg-8 offset-2">
        <div class="box">

    Cena varstva

    Cena mesečnega varstva je 350,00 € za enega otroka. V primeru dveh otrok iz iste družine znaša cena 300,00 € za vsakega otroka.

    V ceno so všteti 4 obroki hrane dnevno, neomejena količina nesladkanih napitkov, pripomočki za ustvarjanje in igro.

    Plenice prinesejo starši s seboj.

        </div>
    </div>
    </div>
</div>
@endsection