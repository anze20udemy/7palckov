
<div class="tagline-upper text-center text-heading text-shadow text-white mt-5 d-none d-lg-block">Varstvo otrok 7 palčkov</div>
<div class="tagline-lower text-center text-expanded text-shadow text-uppercase text-white mb-5 d-none d-lg-block"></div>
