@include('admin.includes.header')

@yield('styles')

@include('admin.includes.navigation')


@yield('content')

@yield('scripts')

@include('admin.includes.footer')